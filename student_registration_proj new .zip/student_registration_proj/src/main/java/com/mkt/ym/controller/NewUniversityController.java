package com.mkt.ym.controller;

import java.io.IOException;

import com.mkt.ym.entity.Address;
import com.mkt.ym.entity.Parent;
import com.mkt.ym.entity.SchoolInfo;
import com.mkt.ym.entity.Student;
import com.mkt.ym.entity.UniversityInfo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {
		"/admin/addStudent",
		"/admin/addUniInfo",
		"/admin/addSchoolInfo",
		"/admin/addParent",
		"/admin/addAddress"
		
})
public class NewUniversityController extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	private static UniversityInfo uniInfo;
	private static Student student;
	private static SchoolInfo school;
	private static Parent parent;
	private static Address address;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				
		switch(req.getServletPath()) {
		
		case"/admin/addStudent":
			student = addStudent(req);
			break;		
		case"/admin/addUniInfo":
			uniInfo = getUniInfo(req);
			break;
		case"/admin/addSchoolInfo":
			school = addSchoolInfo(req);
			break;
		case"/admin/addParent":
			parent = addParent(req);
			break;			
		case"/admin/addAddress":
			 address = addAddress(req);
			;
		}
		saveUniInfo(student,uniInfo,school,parent,address);
		req.getRequestDispatcher("/admin/info-student.jsp").forward(req, resp);
	}

	private void saveUniInfo(Student student2, UniversityInfo uniInfo2, SchoolInfo school2, Parent parent2,
			Address address2) {
		if(null == student2) {
			
		}
	}

	private Address addAddress(HttpServletRequest req) {
		return null;
	}

	private Parent addParent(HttpServletRequest req) {
		return null;
	}

	private SchoolInfo addSchoolInfo(HttpServletRequest req) {
		return null;
	}

	private Student addStudent(HttpServletRequest req) {
		return null;
	}
	

	private void clear() {
		uniInfo = null;
		student = null;
	}
	
	private static UniversityInfo getUniInfo(HttpServletRequest req) {
		if(null == uniInfo) {
			return new UniversityInfo();
		}
		return uniInfo;
	}

}
