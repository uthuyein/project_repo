package com.mkt.ym.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "payment_tbl")
public class PaymentRegister {

	@EmbeddedId
	private RegisterPk id;
	private String transactionNum;	
	private int amount;
	private String note;
	
	@ManyToOne
	private UniversityInfo uniInfo;
	@Column(columnDefinition = "tinyint(1) default 1")
	private boolean active;
	
}
