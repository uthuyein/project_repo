package com.mkt.ym.entity;

import java.io.Serializable;

import com.mkt.ym.entity.type.PaymentType;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RegisterPk implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "uniInfo_id")
	private Integer uniInfoId;
	private String transferFrom;
	
	@Enumerated(EnumType.STRING)
	private PaymentType paymentType;
}
