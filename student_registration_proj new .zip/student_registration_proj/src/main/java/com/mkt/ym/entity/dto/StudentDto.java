package com.mkt.ym.entity.dto;

import java.time.LocalDate;

public record StudentDto(String name,String email,LocalDate dob) {

}
