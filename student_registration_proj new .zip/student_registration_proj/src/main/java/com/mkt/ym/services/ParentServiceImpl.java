package com.mkt.ym.services;

import java.util.List;

import com.mkt.ym.entity.Parent;

public class ParentServiceImpl implements ParentService {

	@Override
	public void save(Parent t) {
		// TODO Auto-generated method stub

	}

	@Override
	public int update(Parent t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Parent> search(Parent t) {
		// TODO Auto-generated method stub
		return null;
	}

}
