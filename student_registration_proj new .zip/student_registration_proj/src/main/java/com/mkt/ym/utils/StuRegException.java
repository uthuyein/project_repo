package com.mkt.ym.utils;

public class StuRegException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public StuRegException(String message) {
		super(message);
	}

}
