 insert into account_tbl(loginId,password,role)values('admin','admin',1);
 insert into account_tbl(loginId,password,role)values('student','student',2);