package com.mkt.ym.entity;

import com.mkt.ym.entity.type.MessageType;

public record Message(String message,MessageType type) {

}
