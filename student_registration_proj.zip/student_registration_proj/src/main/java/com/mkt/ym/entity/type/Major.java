package com.mkt.ym.entity.type;

public enum Major{
	JST,CE,ECE,PRE,AME
}