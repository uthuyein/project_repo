package com.mkt.ym.entity.type;

public enum PaymentType {

	KBZ,AYA,WAVE
}
