package com.mkt.ym.entity.type;

public enum Role{
	ADMIN,STUDENT;
}