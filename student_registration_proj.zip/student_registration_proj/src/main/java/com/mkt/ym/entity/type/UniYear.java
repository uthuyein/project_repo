package com.mkt.ym.entity.type;

public enum UniYear {
	FIRST, SECOND, THIRD, FOURTH, FIFTH
}