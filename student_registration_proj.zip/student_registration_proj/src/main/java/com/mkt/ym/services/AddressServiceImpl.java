package com.mkt.ym.services;

import java.util.List;

import com.mkt.ym.entity.Address;

public class AddressServiceImpl implements AddressService {

	@Override
	public void save(Address t) {
		// TODO Auto-generated method stub

	}

	@Override
	public int update(Address t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Address> search(Address t) {
		// TODO Auto-generated method stub
		return null;
	}

}
