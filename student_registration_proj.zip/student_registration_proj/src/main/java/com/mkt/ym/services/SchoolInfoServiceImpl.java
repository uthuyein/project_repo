package com.mkt.ym.services;

import java.util.List;

import com.mkt.ym.entity.SchoolInfo;

public class SchoolInfoServiceImpl implements SchoolInfoService {

	@Override
	public void save(SchoolInfo t) {
		// TODO Auto-generated method stub

	}

	@Override
	public int update(SchoolInfo t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<SchoolInfo> search(SchoolInfo t) {
		// TODO Auto-generated method stub
		return null;
	}

}
